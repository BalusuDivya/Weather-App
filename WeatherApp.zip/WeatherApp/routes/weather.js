// routes/weather.js
const express = require('express');
const axios = require('axios');
const Search = require('../models/Search');
const router = express.Router();

const openWeatherApiKey = process.env.OPENWEATHER_API_KEY;

// Serve the main page at the root path
router.get('/', async (req, res) => {
  const query = req.query.city || '';
  let weatherData = null;
  const recentSearches = await Search.find().sort({ date: -1 }).limit(5); // Get last 5 searches

  if (query) {
    try {
      // Fetch weather data from OpenWeather API
      const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${query}&appid=${openWeatherApiKey}&units=metric`);
      weatherData = response.data;

      // Save search to MongoDB
      await Search.create({ city: query });

    } catch (error) {
      console.error('Error fetching weather data:', error);
    }
  }

  // Render the page with weather data and recent searches
  res.render('index', { weatherData, recentSearches, query });
});

module.exports = router;
